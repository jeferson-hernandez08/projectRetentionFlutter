import 'package:app_projectretention_711_v1/api/apiRetention.dart';
import 'package:app_projectretention_711_v1/main.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart'; // Para formatear fechas

final TextEditingController firstNameController = TextEditingController();
final TextEditingController lastNameController = TextEditingController();
final TextEditingController emailController = TextEditingController();
final TextEditingController phoneController = TextEditingController();
final TextEditingController documentController = TextEditingController();
final TextEditingController passwordController = TextEditingController();
final TextEditingController coordinadorTypeController = TextEditingController();
final TextEditingController rolIdController = TextEditingController();
// final TextEditingController passwordResetTokenController = TextEditingController();
// final TextEditingController passwordResetExpiresController = TextEditingController();

modalEditNewUser(context, option, dynamic listItem) {
  // Creamos una clave global para el formulario | Para campo clave y campos obligatorios
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

   // Variables para los valores seleccionados en los dropdowns
  String? selectedManager;
  String? selectedCoordinadorType; // Nueva variable para el tipo de coordinador
  DateTime? selectedPasswordResetExpires;

  showModalBottomSheet(
    isScrollControlled: true,
    context: context, 
    builder: (context) {
      if(option == "new") { 
        firstNameController.clear();   // Limpiar campos
        lastNameController.clear();   // Limpiar campos
        emailController.clear();   // Limpiar campos
        phoneController.clear();   // Limpiar campos
        documentController.clear();   // Limpiar campos
        passwordController.clear();   // Limpiar campos
        coordinadorTypeController.clear();   // Limpiar campos
        rolIdController.clear();   // Limpiar campos
        // passwordResetTokenController.clear();   // Limpiar campos
        // passwordResetExpiresController.clear();   // Limpiar campos
        selectedManager = null;
        selectedCoordinadorType = null; // Inicializar como nulo para nuevo usuario
        selectedPasswordResetExpires = null;
      } else {
        firstNameController.text = listItem['firstName'] ?? 'Sin nombre';
        lastNameController.text = listItem['lastName'] ?? 'Sin apellido';
        emailController.text = listItem['email'] ?? 'Sin email';
        phoneController.text = listItem['phone'] ?? 'Sin teléfono';
        documentController.text = listItem['document'] ?? 'Sin documento';
        passwordController.text = listItem['password'] ?? 'Sin password';
        coordinadorTypeController.text = listItem['coordinadorType'] ?? '';
        rolIdController.text = listItem['fkIdRols'].toString() ?? 'Sin rolId'; // ✅ Convertir a String
        // passwordResetTokenController.text = listItem['passwordResetToken'] ?? 'Sin token de reset';

        // Establecer valores para los dropdowns
        selectedManager = listItem['manager']?.toString() ?? null;
        selectedCoordinadorType = listItem['coordinadorType'] ?? null; // Establecer valor existente
        
        // Procesar fecha de expiración de reset si existe
        if (listItem['passwordResetExpires'] != null) {
          try {
            selectedPasswordResetExpires = DateTime.parse(listItem['passwordResetExpires']);
            // passwordResetExpiresController.text = DateFormat('yyyy-MM-dd').format(selectedPasswordResetExpires!);
          } catch (e) {
            // passwordResetExpiresController.text = listItem['passwordResetExpires'] ?? '';
          }
        }
      }

      return StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          // 👇🏼 Capturar los roles solo si no están en memoria
          if (myReactController.getListRols.isEmpty) {
            fetchAPIRols().then((_) {
              setState(() {}); // Refresca cuando termine la API
            });
          }

          return Scaffold(
            appBar: AppBar(
              title: (option == "new") ? Text('Crear Nuevo Usuario') : Text('Editar Usuario'),
              backgroundColor: (option == "new") ? Colors.green : Colors.blue,
              foregroundColor: Colors.white,
              centerTitle: true,     // Propiedad para centrar el titulo
            ),
            floatingActionButton: FloatingActionButton(
              backgroundColor: (option == "new") ? Colors.green : Colors.blue,
              foregroundColor: Colors.white,
              child: Icon(option == "new" ? Icons.add : Icons.edit),
              onPressed: () async {
                // Validar formulario antes de proceder
                if (!_formKey.currentState!.validate()) {
                  Get.snackbar(
                    'Campos incompletos', 
                    'Por favor, complete todos los campos obligatorios',
                    colorText: Colors.white,
                    backgroundColor: Colors.orange
                  );
                  return;
                }
                
                if(option == "new") {
                  // Lógica para crear un nuevo usuario
                  bool resp = await newUserApi(
                    firstNameController.text, 
                    lastNameController.text,
                    emailController.text,
                    phoneController.text,
                    documentController.text,
                    passwordController.text,
                    selectedCoordinadorType ?? '', // Usar el valor seleccionado
                    selectedManager ?? 'false', // Valor por defecto false
                    rolIdController.text,
                    // passwordResetTokenController.text, 
                    // selectedPasswordResetExpires != null ? DateFormat('yyyy-MM-dd').format(selectedPasswordResetExpires!) : null
                  );
                  Get.back();  // Cerrar el modal
                  if(resp) {
                    Get.snackbar(
                      'Mensaje', "Se ha añadido correctamente un nuevo usuario", 
                      colorText: Colors.white,
                      backgroundColor: Colors.green
                    );
                  } else {
                      Get.snackbar(
                        'Mensaje', "Error al agregar el nuevo usuario", 
                        colorText: Colors.white,
                        backgroundColor: Colors.red
                      );
                  }
                  
                } else {   
                  // En caso de editar el usuario
                  bool resp = await editUserApi(
                    listItem['id'],
                    firstNameController.text, 
                    lastNameController.text,
                    emailController.text,
                    phoneController.text,
                    documentController.text,
                    passwordController.text,
                    selectedCoordinadorType ?? '', // Usar el valor seleccionado
                    selectedManager ?? 'false',
                    rolIdController.text,
                    // passwordResetTokenController.text,
                    // selectedPasswordResetExpires != null ? DateFormat('yyyy-MM-dd').format(selectedPasswordResetExpires!) : null
                  );
                  Get.back();  // Cerrar el modal
                  if(resp) {
                    Get.snackbar(
                    'Mensaje', "Se ha editado correctamente el usuario", 
                    colorText: Colors.green,
                    backgroundColor: Colors.greenAccent
                    );
                  } else {
                      Get.snackbar('Mensaje', "Error al editar el usuario", colorText: Colors.red);
                  }
                }
              
              }),

              body: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Form(
                  key: _formKey, // Asignar la clave al formulario
                  child: ListView(
                    children: [
                      TextFormField(
                        controller: firstNameController,
                        decoration: InputDecoration(
                          labelText: 'Nombre *',
                          hintText: 'Ingrese el nombre',
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Este campo es obligatorio';
                          }
                          return null;
                        },
                      ),

                      TextFormField(
                        controller: lastNameController,
                        decoration: InputDecoration(
                          labelText: 'Apellido *',
                          hintText: 'Ingrese el apellido',
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Este campo es obligatorio';
                          }
                          return null;
                        },
                      ),

                      TextFormField(
                        controller: emailController,
                        decoration: InputDecoration(
                          labelText: 'Email *',
                          hintText: 'Ingrese el email',
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Este campo es obligatorio';
                          }
                          if (!value.contains('@')) {
                            return 'Ingrese un email válido';
                          }
                          return null;
                        },
                      ),

                      TextFormField(
                        controller: phoneController, 
                        decoration: InputDecoration(
                          labelText: 'Teléfono',
                          hintText: 'Ingrese el teléfono',
                        ),
                      ),

                      TextFormField(
                        controller: documentController, 
                        decoration: InputDecoration(
                          labelText: 'Documento *',
                          hintText: 'Ingrese número de documento',
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Este campo es obligatorio';
                          }
                          return null;
                        },
                      ),

                      TextFormField(
                        controller: passwordController, 
                        decoration: InputDecoration(
                          labelText: 'Password *',
                          hintText: 'Ingrese la contraseña',
                        ),
                        obscureText: true,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Este campo es obligatorio';
                          }
                          if (value.length < 6) {
                            return 'La contraseña debe tener al menos 6 caracteres';
                          }
                          return null;
                        },
                      ),

                      SizedBox(height: 16),

                      // Dropdown para Tipo de Coordinador
                      DropdownButtonFormField<String>(
                        value: selectedCoordinadorType,
                        decoration: InputDecoration(
                          labelText: 'Tipo de Coordinador',
                          border: OutlineInputBorder(),
                          contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        ),
                        hint: Text('Seleccione el tipo de coordinador'),
                        items: [
                          DropdownMenuItem(
                            value: null,
                            child: Text('No es coordinador'),
                          ),
                          DropdownMenuItem(
                            value: 'academico',
                            child: Text('Coordinador académico'),
                          ),
                          DropdownMenuItem(
                            value: 'formacion',
                            child: Text('Coordinador de formación'),
                          ),
                        ],
                        onChanged: (String? newValue) {
                          setState(() {
                            selectedCoordinadorType = newValue;
                            coordinadorTypeController.text = newValue ?? '';
                          });
                        },
                      ),

                      SizedBox(height: 16),
                    
                      // Dropdown para Manager
                      DropdownButtonFormField<String>(
                        value: selectedManager,
                        decoration: InputDecoration(
                          labelText: 'Es Manager *',
                          border: OutlineInputBorder(),
                          contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        ),
                        hint: Text('Seleccione opción'),
                        items: [
                          DropdownMenuItem(
                            value: 'true',
                            child: Text('Sí'),
                          ),
                          DropdownMenuItem(
                            value: 'false',
                            child: Text('No'),
                          ),
                        ],
                        onChanged: (String? newValue) {
                          setState(() {
                            selectedManager = newValue;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Este campo es obligatorio';
                          }
                          return null;
                        },
                      ),
                      
                      SizedBox(height: 16),

                      DropdownButtonFormField<String>(
                        value: rolIdController.text.isNotEmpty ? rolIdController.text : null,
                        decoration: InputDecoration(
                          labelText: 'Rol *',
                          border: OutlineInputBorder(),
                          contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        ),
                        hint: Text('Seleccione un rol'),
                        items: myReactController.getListRols.map<DropdownMenuItem<String>>((rol) {
                          return DropdownMenuItem<String>(
                            value: rol['id'].toString(),
                            child: Text(rol['name']),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          setState(() {
                            rolIdController.text = newValue ?? '';
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Este campo es obligatorio';
                          }
                          return null;
                        },
                      ),

                      // Los campos de passwordResetToken y passwordResetExpires
                      // se mantienen comentados como en el original
                      /*
                      TextFormField(
                        controller: passwordResetTokenController,
                        decoration: InputDecoration(
                          labelText: 'Token de Reset',
                          hintText: 'Ingrese token de recuperación',
                          ),
                        ),

                      TextFormField(
                        controller: passwordResetExpiresController,
                        decoration: InputDecoration(
                          labelText: 'Expiración Reset',
                          hintText: 'Ingrese fecha de expiración',
                          ),
                        ),
                      */
                    ],
                  ),
                ),
              ),
          );
        }
      );
    }
  );
}