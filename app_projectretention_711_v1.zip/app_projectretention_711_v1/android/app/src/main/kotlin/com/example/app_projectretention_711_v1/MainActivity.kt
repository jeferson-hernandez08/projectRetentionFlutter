package com.example.app_projectretention_711_v1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
